package com.advanced.intelligent.tourist.guide.Advanced.Intelligent.Tourist.Guide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedIntelligentTouristGuideApplicationTests {

	@Test
	void contextLoads() {
	}

}
