package com.advanced.intelligent.tourist.guide.Advanced.Intelligent.Tourist.Guide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedIntelligentTouristGuideApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvancedIntelligentTouristGuideApplication.class, args);
	}

}
